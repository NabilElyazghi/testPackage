from setuptools import setup,find_packages

setup(
    name='mypackage',
    version='0.1',
    author="Nabil elyazghi",
    author_email="n_ejjabri@gmail.com"
)